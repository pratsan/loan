package com.star.mortgage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MortgageApplicationTests {

	@Test
	void contextLoads() {
	}

}
