package com.star.mortgage.exception;

public class InvalidAccountException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidAccountException(String arg0) {
		super(arg0);
		
	}
	

}
