/**
 * 
 */
package com.star.mortgage.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.star.mortgage.entity.Transaction;

/**
 * @author User1
 *
 */
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
	
	public List<Transaction> findByAccountNumber(String accountNumber);


}
