package com.star.mortgage.exception;

public class NoLoanFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoLoanFoundException(String message) {
		super(message);
		
	}
	

}
