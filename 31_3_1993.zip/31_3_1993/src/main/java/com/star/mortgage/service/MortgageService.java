/**
 * 
 */
package com.star.mortgage.service;

import com.star.mortgage.dto.MortgageDetailsDto;
import com.star.mortgage.dto.MortgageDto;
import com.star.mortgage.exception.AgeValidException;
import com.star.mortgage.exception.EmailValidationException;
import com.star.mortgage.exception.EmiException;
import com.star.mortgage.exception.PhoneNumberException;
import com.star.mortgage.exception.PropertyCostException;
import com.star.mortgage.exception.TenureException;
import com.star.mortgage.exception.UserExistException;

/**
 * @author User1
 *
 */
public interface MortgageService  {

	/**
	 * @param mortgageDto
	 * @return
	 * @throws PropertyCostException
	 * @throws PhoneNumberException
	 * @throws EmailValidationException
	 * @throws AgeValidException
	 * @throws TenureException
	 */
	public MortgageDetailsDto mortgageRegister(MortgageDto mortgageDto) throws PropertyCostException, PhoneNumberException,
			EmailValidationException, AgeValidException, TenureException , EmiException,UserExistException;

}
