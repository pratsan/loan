/**
 * 
 */
package com.star.mortgage.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.star.mortgage.utility.ErrorConstants;

/**
 * @author User1
 *
 */
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(PropertyCostException.class)
	public ResponseEntity<ErrorResponse> error(PropertyCostException ex) {

		ErrorResponse er = new ErrorResponse();
		er.setMessage(ex.getMessage());
		er.setStatus(ErrorConstants.PROPERTY_COST_VALIDATION_MESSAGE_CODE);
		return new ResponseEntity<>(er, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler(PhoneNumberException.class)
	public ResponseEntity<ErrorResponse> error(PhoneNumberException ex) {

		ErrorResponse er = new ErrorResponse();
		er.setMessage(ex.getMessage());
		er.setStatus(ErrorConstants.PHONE_VALIDATION_MESSAGE_CODE);
		return new ResponseEntity<>(er, HttpStatus.NOT_FOUND);

	}
	
	@ExceptionHandler(EmailValidationException.class)
	public ResponseEntity<ErrorResponse> error(EmailValidationException ex) {

		ErrorResponse er = new ErrorResponse();
		er.setMessage(ex.getMessage());
		er.setStatus(ErrorConstants.EMAIL_VALIDATION_MESSAGE_CODE);
		return new ResponseEntity<>(er, HttpStatus.NOT_FOUND);

	}
	
	@ExceptionHandler(AgeValidException.class)
	public ResponseEntity<ErrorResponse> error(AgeValidException ex) {

		ErrorResponse er = new ErrorResponse();
		er.setMessage(ex.getMessage());
		er.setStatus(ErrorConstants.CUSTOMER_AGE_MINIMUM_MESSAGE_CODE);
		return new ResponseEntity<>(er, HttpStatus.NOT_FOUND);

	}
	
	@ExceptionHandler(TenureException.class)
	public ResponseEntity<ErrorResponse> error(TenureException ex) {

		ErrorResponse er = new ErrorResponse();
		er.setMessage(ex.getMessage());
		er.setStatus(ErrorConstants.TENURE_MINIMUM_MESSAGE_CODE);
		return new ResponseEntity<>(er, HttpStatus.NOT_FOUND);

	}
	
	@ExceptionHandler(EmiException.class)
	public ResponseEntity<ErrorResponse> error(EmiException ex) {

		ErrorResponse er = new ErrorResponse();
		er.setMessage(ex.getMessage());
		er.setStatus(ErrorConstants.TENURE_MINIMUM_MESSAGE_CODE);
		return new ResponseEntity<>(er, HttpStatus.NOT_FOUND);

	}
	
	@ExceptionHandler(UserExistException.class)
	public ResponseEntity<ErrorResponse> error(UserExistException ex) {

		ErrorResponse er = new ErrorResponse();
		er.setMessage(ex.getMessage());
		er.setStatus(ErrorConstants.CUSTOMER_EXIST_CODE);
		return new ResponseEntity<>(er, HttpStatus.NOT_FOUND);

	}
	
	@ExceptionHandler(NoLoanFoundException.class)
	public ResponseEntity<ErrorResponse> error(NoLoanFoundException ex) {

		ErrorResponse er = new ErrorResponse();
		er.setMessage(ex.getMessage());
		er.setStatus(ErrorConstants.NO_LOAN_RECORD_CODE);
		return new ResponseEntity<>(er, HttpStatus.NOT_FOUND);

	}
	
	@ExceptionHandler(CustomerException.class)
	public ResponseEntity<ErrorResponse> error(CustomerException ex) {

		ErrorResponse er = new ErrorResponse();
		er.setMessage(ex.getMessage());
		er.setStatus(ErrorConstants.NO_ID_FOUND_CODE);
		return new ResponseEntity<>(er, HttpStatus.NOT_FOUND);

	}


}
