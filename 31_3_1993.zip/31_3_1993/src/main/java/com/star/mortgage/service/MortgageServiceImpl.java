/**
 * 
 */
package com.star.mortgage.service;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.star.mortgage.dto.MortgageDetailsDto;
import com.star.mortgage.dto.MortgageDto;
import com.star.mortgage.entity.Account;
import com.star.mortgage.entity.Customer;
import com.star.mortgage.entity.Mortgage;
import com.star.mortgage.exception.AgeValidException;
import com.star.mortgage.exception.EmailValidationException;
import com.star.mortgage.exception.EmiException;
import com.star.mortgage.exception.PhoneNumberException;
import com.star.mortgage.exception.PropertyCostException;
import com.star.mortgage.exception.TenureException;
import com.star.mortgage.exception.UserExistException;
import com.star.mortgage.repository.AccountRepository;
import com.star.mortgage.repository.CustomerRepository;
import com.star.mortgage.repository.MortgageRepository;
import com.star.mortgage.utility.ErrorConstants;

/**
 * @author Nagajyoti
 *
 */

@Service
public class MortgageServiceImpl implements MortgageService {

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	MortgageRepository mortgageRepository;

	@Autowired
	AccountRepository accountRepository;

	Random random = new Random();

	double rateOfInterest = 20.0;

	private static final Logger LOGGER = LoggerFactory.getLogger(MortgageServiceImpl.class);

	@Override
	public MortgageDetailsDto mortgageRegister(MortgageDto mortgageDto)
			throws PropertyCostException, PhoneNumberException, EmailValidationException, AgeValidException,
			TenureException, EmiException, UserExistException {

		LOGGER.debug("MortgageServiceImpl:mortgageRegister");

		Account transactionalAccount = null;
		Account mortgageAccount = null;
		Customer customer = null;
		Mortgage mortgage = null;

		MortgageDetailsDto mortgageDetailsDto = null;

		LocalDate birthDay = mortgageDto.getDob();

		double cal = (20.0 / 100.0) * mortgageDto.getPropertyCost();

		double priciple = mortgageDto.getPropertyCost() - mortgageDto.getDeposit();
		int tenure = mortgageDto.getTenure();
		double emi;

		emi = emiCalculator(priciple, rateOfInterest, tenure);

		double sal = mortgageDto.getSalary() / 12;

		Customer cust = customerRepository.findByEmail(mortgageDto.getEmail());

		if (cust != null)
			throw new UserExistException(ErrorConstants.CUSTOMER_EXIST);

		if (mortgageDto.getPropertyCost() < 100000 || mortgageDto.getDeposit() < cal)
			throw new PropertyCostException(ErrorConstants.PROPERTY_COST_VALIDATION_MESSAGE);

		if (!validPhoneNumber(mortgageDto.getPhoneNumber()))
			throw new PhoneNumberException(ErrorConstants.PHONE_VALIDATION_MESSAGE);

		if (emailValidation(mortgageDto.getEmail()))
			throw new EmailValidationException(ErrorConstants.EMAIL_VALIDATION_MESSAGE);

		if (validAge(birthDay))
			throw new AgeValidException(ErrorConstants.CUSTOMER_AGE_MINIMUM_MESSAGE);

		if (mortgageDto.getTenure() < 1)
			throw new TenureException(ErrorConstants.TENURE_MINIMUM_MESSAGE);

		if (sal < 0.8 * emi)
			throw new EmiException(ErrorConstants.EMI_MESSAGE);

		mortgage = new Mortgage();
		customer = new Customer();
		mortgageDetailsDto = new MortgageDetailsDto();

		customer.setFirstName(mortgageDto.getFirstName());
		customer.setLastName(mortgageDto.getLastName());
		customer.setDob(mortgageDto.getDob());
		customer.setPhoneNumber(mortgageDto.getPhoneNumber());
		customer.setEmail(mortgageDto.getEmail());
		customer.setPanCard(mortgageDto.getPanCard());
		customer.setOccupation(mortgageDto.getOccupation());
		customer.setSalary(mortgageDto.getSalary());
		customer.setLoginId(mortgageDto.getFirstName() + random.nextInt(1000));
		customer.setPassword(mortgageDto.getFirstName() + "@" + random.nextInt(100));

		Customer customerRepo = customerRepository.save(customer);

		mortgage.setPropertyType(mortgageDto.getPropertyType());
		mortgage.setPropertyCost(mortgageDto.getPropertyCost());
		mortgage.setDeposit(mortgageDto.getDeposit());
		mortgage.setEmployementType(mortgageDto.getEmploymentStatus());
		mortgage.setTenure(mortgageDto.getTenure());
		mortgage.setCustomerId(customerRepo.getCustomerId());

		mortgage.setEmi(emi);
		Mortgage mortgageRepo = mortgageRepository.save(mortgage);

		transactionalAccount = new Account();
		transactionalAccount.setBalance(mortgageDto.getPropertyCost() - mortgageRepo.getDeposit());
		transactionalAccount.setAccountNumber(ErrorConstants.TRANSACTIONAL_ACCOUNT_SUFFIX + random.nextInt(1000));
		transactionalAccount.setAccountType(ErrorConstants.TRANSACTION_ACCOUNT);
		transactionalAccount.setCreatedDate(new Date());
		transactionalAccount.setCustomerId(customerRepo.getCustomerId());
		accountRepository.save(transactionalAccount);

		mortgageAccount = new Account();
		mortgageAccount.setBalance(-(mortgageDto.getPropertyCost() - mortgageRepo.getDeposit()));

		mortgageAccount.setAccountNumber(ErrorConstants.MORTGAGE_ACCOUNT_SUFFIX + random.nextInt(1000));
		mortgageAccount.setAccountType(ErrorConstants.MORTAGE_ACCOUNT);
		mortgageAccount.setCreatedDate(new Date());
		mortgageAccount.setCustomerId(customerRepo.getCustomerId());

		accountRepository.save(mortgageAccount);

		mortgageDetailsDto.setTransactionAccountNumber(transactionalAccount.getAccountNumber());
		mortgageDetailsDto.setMortgageAccountNumber(mortgageAccount.getAccountNumber());
		mortgageDetailsDto.setLoginId(customer.getLoginId());
		mortgageDetailsDto.setPassword(customer.getPassword());
		mortgageDetailsDto.setStatusCode(200);
		mortgageDetailsDto.setMessage(ErrorConstants.MORTGAGE_SUCCESS);

		String from = "nagajyotigorte@gmail.com";
		String password = "*MyBest*#";
		String to = customerRepo.getEmail();
		String subject = "Mortgage Details";
		
		String newline = System.getProperty("line.separator");

		String message = "Transactional Account Number: " + transactionalAccount.getAccountNumber() + " \n"
				+ "Mortgage Account Number: " + mortgageAccount.getAccountNumber() + " \n" + "Login Id :"
				+ customer.getLoginId() + " \n" + "Password :" + customer.getPassword();
		String successMessage = "";
		successMessage = EmailConfiguration.sendMail(from, password, to, subject, message);
		System.out.println(successMessage);

		return mortgageDetailsDto;

	}

	static boolean validPhoneNumber(String number) {
		Pattern p = Pattern.compile("^[0-9]{10}$");
		Matcher m = p.matcher(number);
		return (m.find() && m.group().equals(number));
	}

	static boolean emailValidation(String email) {
		String regex = "[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		return email.matches(regex);
	}

	static boolean validAge(LocalDate date1) {
		boolean result = false;
		int birthYear = date1.getYear();
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int age = year - birthYear;
		if (age < 21) {
			result = true;
		}
		return result;
	}

	static double emiCalculator(double p, double r, double t) {
		r = r / (12 * 100);
		t = t * 12;
		return (p * r * (double) Math.pow(1 + r, t)) / (double) (Math.pow(1 + r, t) - 1);
	}

}
